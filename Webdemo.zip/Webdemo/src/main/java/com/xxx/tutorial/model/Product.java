package com.xxx.tutorial.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import io.swagger.annotations.ApiModel;

/**
 * 
 * @author wangmengjun
 *
 */
@ApiModel(subTypes = {}, value = "this is product!"

)
@XmlType(name="hello xml")
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	
	private Address address;
	/** ID */
	private Long id;

	/** ��Ʒ���� */
	private String name;

	/** ��Ʒ�ͺ� */
	private String productClass;

	/** ��ƷID */
	private String productId;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the productClass
	 */
	public String getProductClass() {
		return productClass;
	}

	/**
	 * @param productClass the productClass to set
	 */
	public void setProductClass(String productClass) {
		this.productClass = productClass;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", productClass=" + productClass + ", productId=" + productId
				+ "]";
	}

}
