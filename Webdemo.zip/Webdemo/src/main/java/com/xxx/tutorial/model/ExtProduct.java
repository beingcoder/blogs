package com.xxx.tutorial.model;

import io.swagger.annotations.ApiModel;


public class ExtProduct extends Product {

	private String extName;

	public String getExtName() {
		return extName;
	}

	public void setExtName(String extName) {
		this.extName = extName;
	}
	
	
	
}
