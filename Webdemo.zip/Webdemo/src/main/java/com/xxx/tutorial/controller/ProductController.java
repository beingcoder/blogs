package com.xxx.tutorial.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.xxx.tutorial.model.ExtProduct;
import com.xxx.tutorial.model.Product;

@RestController
@RequestMapping(value = { "/api/" })
public class ProductController {

	@RequestMapping(value = "product/{id}", method = RequestMethod.GET)
	public ResponseEntity<Product> get(@PathVariable Long id) {
		ExtProduct product = new ExtProduct();
		product.setName(id.toString());
		product.setId(1L);
		product.setProductClass("seven_filters");
		product.setProductId("T12345");
		product.setExtName("stt");
		return ResponseEntity.ok(product);
	}

//	@RequestMapping(value = "/stts", method = RequestMethod.GET)
//	public ResponseEntity<ExtProduct> get() {
//		ExtProduct product = new ExtProduct();
//		product.setExtName("exttttt");
//		product.setName("�߼���о��ˮ��");
//		product.setId(1L);
//		product.setProductClass("seven_filters");
//		product.setProductId("T12345");
//		return ResponseEntity.ok(product);
//	}
}