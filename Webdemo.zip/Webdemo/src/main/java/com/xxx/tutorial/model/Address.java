package com.xxx.tutorial.model;

public class Address  {

	private String extName2;
	private String extName1;
	public String getExtName2() {
		return extName2;
	}


	public String getExtName1() {
		return extName1;
	}

	public void setExtName1(String extName1) {
		this.extName1 = extName1;
	}

	public void setExtName2(String extName2) {
		this.extName2 = extName2;
	}
	
	
	
}
